/* ============================================================
   NAYEM — PORTFOLIO SCRIPT
   Nav, scroll effects, reveal animations, terminal typing,
   skill bars, contact form handling
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Header scroll state + scroll progress ---------- */
  const header = document.getElementById('siteHeader');
  const scrollProgress = document.getElementById('scrollProgress');
  const backToTop = document.getElementById('backToTop');

  function onScroll() {
    const scrolled = window.scrollY;
    header.classList.toggle('is-scrolled', scrolled > 12);
    backToTop.classList.toggle('is-visible', scrolled > 480);

    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = docHeight > 0 ? (scrolled / docHeight) * 100 : 0;
    scrollProgress.style.width = progress + '%';
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ---------- Mobile nav toggle ---------- */
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');

  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('is-open');
    navToggle.classList.toggle('is-open', isOpen);
    navToggle.setAttribute('aria-expanded', String(isOpen));
    navToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
  });

  navLinks.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('is-open');
      navToggle.classList.remove('is-open');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  });

  /* ---------- Scroll-spy: highlight active nav link ---------- */
  const sections = document.querySelectorAll('main section[id]');
  const navLinkMap = new Map();
  document.querySelectorAll('.nav-link').forEach((link) => {
    navLinkMap.set(link.getAttribute('href').slice(1), link);
  });

  const spyObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      const link = navLinkMap.get(entry.target.id);
      if (!link) return;
      if (entry.isIntersecting) {
        navLinkMap.forEach((l) => l.classList.remove('is-active'));
        link.classList.add('is-active');
      }
    });
  }, { rootMargin: '-45% 0px -50% 0px', threshold: 0 });

  sections.forEach((s) => spyObserver.observe(s));

  /* ---------- Scroll reveal ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('in-view'), i * 40);
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealEls.forEach((el) => revealObserver.observe(el));

  /* ---------- Skill bar fill on reveal ---------- */
  const skillBars = document.querySelectorAll('.skill-bar-fill');
  const skillObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const fill = entry.target;
        fill.style.width = fill.dataset.width + '%';
        skillObserver.unobserve(fill);
      }
    });
  }, { threshold: 0.4 });

  skillBars.forEach((bar) => skillObserver.observe(bar));

  /* ---------- Hero terminal typing effect ---------- */
  const terminalBody = document.getElementById('terminalBody');
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const terminalLines = [
    { prompt: '$ whoami', delay: 0 },
    { key: 'name', val: 'Nayem' },
    { key: 'role', val: 'Software Developer' },
    { key: 'based_in', val: 'Bangladesh' },
    { key: 'stack', val: 'JavaScript · Python · SQL' },
    { prompt: '$ status --check', delay: 0 },
    { key: 'availability', val: 'Open to freelance work' }
  ];

  function renderLineStatic(line) {
    const div = document.createElement('div');
    if (line.prompt) {
      div.innerHTML = `<span class="line-prompt">${line.prompt}</span>`;
    } else {
      div.innerHTML = `<span class="line-key">${line.key}:</span> <span class="line-val">${line.val}</span>`;
    }
    return div;
  }

  function typeTerminal() {
    if (!terminalBody) return;

    if (prefersReducedMotion) {
      terminalBody.innerHTML = '';
      terminalLines.forEach((line) => terminalBody.appendChild(renderLineStatic(line)));
      return;
    }

    let lineIndex = 0;

    function typeNextLine() {
      if (lineIndex >= terminalLines.length) {
        const cursor = document.createElement('span');
        cursor.className = 'terminal-cursor';
        terminalBody.appendChild(cursor);
        return;
      }

      const line = terminalLines[lineIndex];
      const lineEl = document.createElement('div');
      terminalBody.appendChild(lineEl);

      const fullText = line.prompt
        ? `<span class="line-prompt">${line.prompt}</span>`
        : `<span class="line-key">${line.key}:</span> <span class="line-val">${line.val}</span>`;

      const plainText = line.prompt || `${line.key}: ${line.val}`;
      let charIndex = 0;

      function typeChar() {
        charIndex++;
        if (charIndex >= plainText.length) {
          lineEl.innerHTML = fullText;
          lineIndex++;
          setTimeout(typeNextLine, line.prompt ? 260 : 120);
        } else {
          lineEl.textContent = plainText.slice(0, charIndex);
          setTimeout(typeChar, line.prompt ? 28 : 16);
        }
      }
      typeChar();
    }

    typeNextLine();
  }

  typeTerminal();

  /* ---------- Contact form handling ---------- */
  const form = document.getElementById('contactForm');
  const formStatus = document.getElementById('formStatus');
  const submitBtn = document.getElementById('formSubmitBtn');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const name = form.name.value.trim();
      const email = form.email.value.trim();
      const subject = form.subject.value.trim();
      const message = form.message.value.trim();
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!name || !email || !subject || !message) {
        showStatus('Please fill in every field before sending.', 'error');
        return;
      }
      if (!emailPattern.test(email)) {
        showStatus('Please enter a valid email address.', 'error');
        return;
      }

      const endpoint = form.getAttribute('action');
      const isPlaceholderEndpoint = !endpoint || endpoint.includes('YOUR_FORM_ID');

      if (isPlaceholderEndpoint) {
        console.warn('Contact form has no backend configured.');
        showStatus('This form isn\'t connected to an inbox yet — please email directly for now.', 'error');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.querySelector('.btn-label').textContent = 'Sending...';

      try {
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { Accept: 'application/json' },
          body: new FormData(form)
        });

        if (response.ok) {
          showStatus('Thanks — your message has been sent. I\'ll reply soon.', 'success');
          form.reset();
        } else {
          showStatus('Something went wrong sending that. Please try again or email directly.', 'error');
        }
      } catch (err) {
        showStatus('Network error — please check your connection and try again.', 'error');
      } finally {
        submitBtn.disabled = false;
        submitBtn.querySelector('.btn-label').textContent = 'Send Message';
      }
    });
  }

  function showStatus(message, type) {
    formStatus.textContent = message;
    formStatus.classList.remove('is-success', 'is-error');
    formStatus.classList.add(type === 'success' ? 'is-success' : 'is-error');
  }

  /* ---------- Footer year ---------- */
  const footerYear = document.getElementById('footerYear');
  if (footerYear) footerYear.textContent = new Date().getFullYear();

});
